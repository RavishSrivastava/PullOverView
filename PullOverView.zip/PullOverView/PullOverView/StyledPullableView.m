


#import "StyledPullableView.h"

@implementation StyledPullableView


- (id)initWithFrame:(CGRect)frame{
    if ((self = [super initWithFrame:frame])) {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StyledPullableView" owner:self options:nil];
        UIView *view = [[UIView alloc] init];
        view = (UIView *)[nib objectAtIndex:0];
        
        UIView *contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 40, self.frame.size.width, self.frame.size.height)];
        [contentView addSubview:view];
        [self addSubview:contentView];
        
    }
        
    return self;
}

-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor redColor];
    if (indexPath.row == 0) {
        cell.backgroundColor = [UIColor grayColor];
        UILabel *HeadingLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 0,tableView.frame.size.width-60 , 40)];
        HeadingLabel.text = @"Custom View";
        
        HeadingLabel.textColor = [self colorWithHexString:@"30A8DF"];
        [HeadingLabel setFont:[UIFont fontWithName:@"Roboto-Bold" size:18]];
        [cell.contentView addSubview:HeadingLabel];
        
        UILabel *iconLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 55, 20, 20)];
        iconLabel.text = @"\uf017";
        
        iconLabel.textColor = [self colorWithHexString:@"F48F20"];
        [iconLabel setFont:[UIFont fontWithName:@"FontAwesome" size:18]];
        [cell.contentView addSubview:iconLabel];
        
        UILabel *iconLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(30, 80, 20, 20)];
        iconLabel2.text = @"\uf041";
        iconLabel2.textColor = [self colorWithHexString:@"F48F20"];
        [iconLabel2 setFont:[UIFont fontWithName:@"FontAwesome" size:18]];
        [cell.contentView addSubview:iconLabel2];
    }
    
    return cell;
}


@end
