




#import "PullableView.h"


@interface StyledPullableView : PullableView<UITableViewDataSource,UITableViewDelegate>



@end
