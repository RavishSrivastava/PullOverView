
//
//  Created by Ravish Kumar on 10/08/15.

//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "StyledPullableView.h"
#import "PullableView.h"


@interface MainViewController : UIViewController<PullableViewDelegate>
{
    
    StyledPullableView *pullUpView;
    UILabel *pullUpLabel;
    IBOutlet MKMapView *mapview;
}
@property (retain, nonatomic) IBOutlet MKMapView *mapview;



@end